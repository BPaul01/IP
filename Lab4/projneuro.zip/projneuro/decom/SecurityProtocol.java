// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 17.03.2023 17:26:27
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   SecurityProtocol.java


public class SecurityProtocol
{

    public SecurityProtocol()
    {
    }

    public String getLatestVersion()
    {
        return null;
    }

    public String version;
}
