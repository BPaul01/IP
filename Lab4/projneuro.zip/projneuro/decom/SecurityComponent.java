// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 17.03.2023 17:10:12
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   SecurityComponent.java

import java.util.Vector;

public class SecurityComponent extends UsersDataBase
{

    public SecurityComponent()
    {
    }

    public void requestSecureConnection()
    {
    }

    public boolean connectionSecure;
    public Vector mySignInController;
    public Vector myUsersDataBase;
}
