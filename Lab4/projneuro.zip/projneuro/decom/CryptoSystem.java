// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 17.03.2023 17:25:35
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CryptoSystem.java

import java.util.Vector;

public class CryptoSystem extends SecurityProtocol
{

    public CryptoSystem()
    {
    }

    public String encrypt(String messaje)
    {
        return null;
    }

    public String decrypt(String messaje)
    {
        return null;
    }

    public String key;
    public Vector mySecurityComponent;
}
