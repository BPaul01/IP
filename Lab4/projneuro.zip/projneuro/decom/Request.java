// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 17.03.2023 17:09:42
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Request.java


public class Request
{

    public Request()
    {
    }

    public String resource;
}
