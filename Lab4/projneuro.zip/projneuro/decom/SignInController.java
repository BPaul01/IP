// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 17.03.2023 17:10:38
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   SignInController.java

import java.util.Vector;

public class SignInController extends AplicationSystemConnection
{

    public SignInController()
    {
    }

    public String getUserToken(String userName)
    {
        return null;
    }

    public boolean authentificateUser(String password, String userName)
    {
        return false;
    }

    public boolean validateUserName(String userName)
    {
        return false;
    }

    public boolean loggedIn;
    public Vector myUsersDataBase;
    public Vector mySecurityComponent;
}
