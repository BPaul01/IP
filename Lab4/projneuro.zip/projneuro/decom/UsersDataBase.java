// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 17.03.2023 17:10:58
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   UsersDataBase.java

import java.util.Vector;

public class UsersDataBase
{

    public UsersDataBase()
    {
    }

    public boolean addUser(String userName, String password)
    {
        return false;
    }

    public boolean deleteUser(String userName, String password)
    {
        return false;
    }

    public Integer id;
    public String userName;
    public String password;
    public String token;
    public Vector mySignInController;
    public Vector mySecurityComponent;
}
